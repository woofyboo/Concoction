package net.mcreator.concoction.procedures;

public class CropMintNeighbourBlockChangesProcedure {
	public static boolean execute() {
		return true;
	}
}
