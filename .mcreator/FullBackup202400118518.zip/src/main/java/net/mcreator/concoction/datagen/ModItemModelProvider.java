package net.mcreator.concoction.datagen;

import net.mcreator.concoction.ConcoctionMod;
import net.mcreator.concoction.init.ConcoctionModBlocks;
import net.mcreator.concoction.init.ConcoctionModItems;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.armortrim.TrimMaterial;
import net.minecraft.world.item.armortrim.TrimMaterials;
import net.minecraft.world.level.block.Block;
import net.neoforged.neoforge.client.model.generators.ItemModelBuilder;
import net.neoforged.neoforge.client.model.generators.ItemModelProvider;
import net.neoforged.neoforge.client.model.generators.ModelFile;
import net.neoforged.neoforge.common.data.ExistingFileHelper;
import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredHolder;

import java.util.LinkedHashMap;

public class ModItemModelProvider extends ItemModelProvider {

    public ModItemModelProvider(PackOutput output, ExistingFileHelper existingFileHelper) {
        super(output, ConcoctionMod.MODID, existingFileHelper);
    }

    @Override
    protected void registerModels() {

        simpleItem(ConcoctionModItems.CORN);
        simpleItem(ConcoctionModItems.CORN_SEEDS);
    }


    private ItemModelBuilder simpleItem(DeferredHolder<Item, Item> item) {
        return withExistingParent(item.getId().getPath(),
                new ResourceLocation("item/generated")).texture("layer0",
                new ResourceLocation(ConcoctionMod.MODID,"item/" + item.getId().getPath()));
    }

//    public void evenSimplerBlockItem(DeferredHolder<Block, Block> block) {
//        this.withExistingParent(ConcoctionMod.MODID + ":" + NeoForgeRegistries.BLOCKS.getKey(block.get()).getPath(),
//                modLoc("block/" + NeoForgeRegistries.BLOCKS.getKey(block.get()).getPath()));
//    }

    private ItemModelBuilder simpleBlockItem(DeferredHolder<Block, Block> item) {
        return withExistingParent(item.getId().getPath(),
                new ResourceLocation("item/generated")).texture("layer0",
                new ResourceLocation(ConcoctionMod.MODID,"item/" + item.getId().getPath()));
    }
}
