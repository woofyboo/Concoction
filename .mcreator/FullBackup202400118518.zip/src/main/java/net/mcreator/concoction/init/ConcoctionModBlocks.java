
/*
*    MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.concoction.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.concoction.block.MintCropBlock;
import net.mcreator.concoction.block.MintBlock;
import net.mcreator.concoction.block.FarmlandMintBlock;
import net.mcreator.concoction.ConcoctionMod;

public class ConcoctionModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK, ConcoctionMod.MODID);
	public static final DeferredHolder<Block, Block> MINT = REGISTRY.register("mint", () -> new MintBlock());
	public static final DeferredHolder<Block, Block> FARMLAND_MINT = REGISTRY.register("farmland_mint", () -> new FarmlandMintBlock());
	// Start of user code block custom blocks
	public static final DeferredHolder<Block, Block> CORN_CROP = REGISTRY.register("corn_crop", () -> new MintCropBlock(BlockBehaviour.Properties.of().noOcclusion().noCollission()));
	// End of user code block custom blocks
}
