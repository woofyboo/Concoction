package net.mcreator.concoction.procedures;

public class MintLeafParticleVariant1AdditionalParticleExpiryConditionProcedure {
	public static boolean execute(boolean onGround) {
		return onGround;
	}
}
